from .BaseAgent import BaseAgent


class CreateAgent(BaseAgent): ...
