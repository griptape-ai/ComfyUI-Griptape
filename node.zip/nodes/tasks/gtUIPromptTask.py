from .gtUIBaseTask import gtUIBaseTask


class gtUIPromptTask(gtUIBaseTask):
    CATEGORY = "Griptape/Agent"
